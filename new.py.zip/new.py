import numpy as np
import pandas as pd 
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error,r2_score
from sklearn.model_selection import train_test_split
from xgboost import XGBRegressor

        
df_features = pd.read_csv('/Users/vijayramanan/VS code/features.csv')
df_sales = pd.read_csv('/Users/vijayramanan/VS code/train.csv')

df = pd.merge(df_sales, df_features, on=['Store', 'Date'])
print(df.head())

df['Date'] = pd.to_datetime(df['Date'])
df_grouped = df.groupby('Date')['Weekly_Sales'].sum().reset_index()

plt.figure(figsize=(12, 4))
sns.lineplot(data=df_grouped, x='Date', y='Weekly_Sales')
plt.title("Weekly Sales Over Time")
plt.show()

plt.scatter(data=df_grouped,x='Date', y='Weekly_Sales')
plt.show()

df['IsHoliday'] = df['IsHoliday'].astype(int)

# Extract useful time features
df['Year'] = df['Date'].dt.year
df['Month'] = df['Date'].dt.month
df['Week'] = df['Date'].dt.isocalendar().week

# Drop Date column
df = df.drop('Date', axis=1)
X = df.drop('Weekly_Sales', axis=1)
y = df['Weekly_Sales']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = XGBRegressor(n_estimators=100, learning_rate=0.1, random_state=42)
model.fit(X_train, y_train)

y_pred = model.predict(X_test)
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print("Mean Squared Error:", mse)
print("R² Score:", r2)